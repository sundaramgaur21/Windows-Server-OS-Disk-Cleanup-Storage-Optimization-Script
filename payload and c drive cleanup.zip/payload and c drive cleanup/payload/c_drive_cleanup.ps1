﻿function read-basevars
{
    $function_name=$MyInvocation.MyCommand
#  let's grab the hash table for the basevars
    write-logentrynodisplay "$function_name`: Getting basevars"
    $temp_basevars_hash = @{}
    import-csv C:\sav\basevars.txt -head "name","value" -delimiter "="|ForEach-Object { $temp_basevars_hash[$_.name] = $_.value}
#    $binloc=$($basevars_hash.binloc.tostring())
    foreach ($i in $temp_basevars_hash.GetEnumerator())
    {
        set-variable -name "$($i.name)" -value $($i.value)
    }
    return $temp_basevars_hash
}

function empty_recycle_bin
{
    $function_name=$MyInvocation.MyCommand
    write-logentrynodisplay "$function_name`: Clearing Recycle bin"
    Clear-RecycleBin -force
    write-logentrynodisplay "$function_name`: Completed clearing recycle bin"
}

function get-local-tz
{
    $function_name=$MyInvocation.MyCommand
    switch ($os_ver)
    {
        "6.3.9600"
        {
            $temp_time = [System.DateTime]::Now
            if ([System.TimeZoneInfo]::Local.IsDaylightSavingTime($temp_time)) 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.DaylightName }
            else 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.StandardName
            }
            $current_tz=$temp_timezone
            $current_tz

        }
        "10.0.14393"
        {
            $temp_time = [System.DateTime]::Now
            if ([System.TimeZoneInfo]::Local.IsDaylightSavingTime($temp_time)) 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.DaylightName }
            else 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.StandardName
            }
            $current_tz=$temp_timezone
            $current_tz

        }
        "10.0.17763"
        {
            $temp_time = [System.DateTime]::Now
            if ([System.TimeZoneInfo]::Local.IsDaylightSavingTime($temp_time)) 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.DaylightName }
            else 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.StandardName
            }
            $current_tz=$temp_timezone
            $current_tz
        }
        "10.0.20348"
        {
            $temp_time = [System.DateTime]::Now
            if ([System.TimeZoneInfo]::Local.IsDaylightSavingTime($temp_time)) 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.DaylightName }
            else 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.StandardName
            }
            $current_tz=$temp_timezone
            $current_tz
        }
        "10.0.26100"
        {
            $temp_time = [System.DateTime]::Now
            if ([System.TimeZoneInfo]::Local.IsDaylightSavingTime($temp_time)) 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.DaylightName }
            else 
            {
                $temp_timezone = [System.TimeZoneInfo]::Local.StandardName
            }
            $current_tz=$temp_timezone
            $current_tz
        }
    }
}

function write-logentrynodisplay
{
    $function_name=$MyInvocation.MyCommand
    $logtime=getlogtime
    $logmessage = $logtime + $current_tz + " $env:computername " + $args
    add-content -encoding ASCII C:\Utilities\c_drive_cleanup\c_drive_cleanup.log $logmessage -ErrorAction SilentlyContinue
}

function log-separator
{
   $function_name=$MyInvocation.MyCommand
   write-logentrynodisplay "---------------------------------------------------------"
}

function getlogtime
{
   $function_name=$MyInvocation.MyCommand  
   get-date -format "dd-MMM-yyy HH:mm:ss "
}

# Function to get disk usage
function get-diskusage
{
    $function_name=$MyInvocation.MyCommand  
    $temp_disk = Get-WmiObject -Class Win32_LogicalDisk -Filter "DeviceID='C:'"
    $temp_c_drive_size = [math]::round($temp_disk.size/1gb,2)
    $temp_c_drive_used = [math]::Round(    ($temp_disk.Size - $temp_disk.FreeSpace)/1gb,2)
    $temp_pct_used = [math]::Round( (($temp_disk.Size - $temp_disk.FreeSpace) / $temp_disk.Size * 100),2)
    write-logentrynodisplay "$function_name`: C drive size is $($temp_c_drive_size) GB"
    write-logentrynodisplay "$function_name`: C drive space used is $temp_c_drive_used GB"
    write-logentrynodisplay "$function_name`: C drive is $temp_pct_used% used"
    return $temp_pct_used,$temp_c_drive_size,$temp_c_drive_used
}

function clean_folder ($temp_folder_to_clean) 
{
    $function_name=$MyInvocation.MyCommand

# we want to see if there are actually any files in there to cleanup
    if (test-path $temp_folder_to_clean)
    {
        write-logentrynodisplay "$function_name`: Folder $($temp_folder_to_clean) exists"
        write-logentrynodisplay "$function_name`: Checking for content of $($temp_folder_to_clean)"
        $temp_files_and_folders=get-childitem $($temp_folder_to_clean) -file -recurse|measure-object -sum length
        $temp_files_and_folders_space=[math]::round($temp_files_and_folders.sum/1gb,2)
        if ($temp_files_and_folders.count -gt 0)
        {
            write-logentrynodisplay "$function_name`: There are $($temp_files_and_folders.count) files consuming $($temp_files_and_folders_space)GB in $($temp_folder_to_clean)"
            write-logentrynodisplay "$function_name`: Getting list of files to delete in $($temp_folder_to_clean) "
            switch -wildcard ($($temp_folder_to_clean))
            {
                '*ccmcache*'
                {
                    $temp_files_to_zap=Get-ChildItem -Path $temp_folder_to_clean -file -Recurse| Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-90)} |select name,fullname
                    $delete_subfolders=$false
                }
                '*w3svc*'
                {
                    $temp_files_to_zap=Get-ChildItem -Path $temp_folder_to_clean -file -Recurse | Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-30)} |select name,fullname
                    $delete_subfolders=$false
                }
                '*SoftwareDistribution*'
                {
                    $temp_files_to_zap=Get-ChildItem -Path $temp_folder_to_clean -file -Recurse | Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-30)} |select name,fullname
                    $delete_subfolders=$false
                }
                default
                {
                    $temp_files_to_zap=Get-ChildItem -Path $temp_folder_to_clean -file -Recurse|select name,fullname,size
                    $delete_subfolders=$true
                }
            }
            write-logentrynodisplay "$function_name`: There are $($temp_files_to_zap.count) files in $($temp_folder_to_clean) that will be deleted"
            if ($temp_files_to_zap.count -gt 0)
            {
                write-logentrynodisplay "$function_name`: Below are the files that will be deleted from $($temp_folder_to_clean)"
                for ($k=0;$k -lt $temp_files_to_zap.count;$k++)            
                {
                    write-logentrynodisplay "$function_name`: $($temp_files_to_zap[$k].fullname)"
                }
# now let's actually delete the files
                for ($k=0;$k -lt $temp_files_to_zap.count;$k++)            
                {
                    try
                    {
                        remove-item -Path $($temp_files_to_zap[$k].fullname) -Force -ErrorAction stop
                        write-logentrynodisplay "$function_name`: Removed $($temp_files_to_zap[$k].fullname)"
                    }
                    catch
                    {
                        write-logentrynodisplay "$function_name`: Failed to remove $($temp_files_to_zap[$k].fullname)"
                    }
                }                
            }
# now that the folders should be empty, let's delete the subfolders
            if ($delete_subfolders)
            {
                $subdirectories_to_zap=  get-childitem C:\temp -Directory|select fullname
                for ($k=0;$k -lt $subdirectories_to_zap.count;$k++)
                {
                    try
                    {
                        remove-item -path $($subdirectories_to_zap[$k].fullname) -Force -recurse -ErrorAction stop
                        write-logentrynodisplay "$function_name`: Removed folder $($subdirectories_to_zap[$k].fullname)"
                    }
                    catch
                    {
                        write-logentrynodisplay "$function_name`: Failed to remove folder $($subdirectories_to_zap[$k].fullname)"
                    }
                }
            }
        }
    }
}
# standard start of script
#remove-item -path C:\Utilities\c_drive_cleanup\c_drive_cleanup.log -ErrorAction SilentlyContinue
$script_name="C_DRIVE_CLEANUP_SCRIPT"
#region parameter section
$os_ver=(get-ciminstance win32_operatingsystem).version
$os_caption=(get-ciminstance win32_operatingsystem).caption
$current_tz=get-local-tz
# value is percentage (of free space)
$threshold_to_initiate_cleanup=85
# value is GB
$log_file_size_threshold=5

$folder_to_check=@(
    "c:\temp",
    "c:\windows\temp",
    "c:\Windows\SoftwareDistribution\Download",
    "c:\Windows\ccmcache"
)

if ($($basevars_hash.isiis) -eq "True")
{
    $folder_to_check += "c:\inetpub\logs\logfiles\w3svc1"
}

#endregion parameter section
# let's keep our own log file from growing too much -- if it's > 10GB, let's blow it away
if (   (get-childitem -path C:\Utilities\c_drive_cleanup\c_drive_cleanup.log).Length/1gb  -gt $log_file_size_threshold )
{
    try
    {
        remove-item -path C:\Utilities\c_drive_cleanup\c_drive_cleanup.log -Force -ErrorAction stop
    }
    catch
    {
        write-logentrynodisplay "$script_name`: Drive cleanup log file > $($log_file_size_threshold)GB in size.  Unable to remove file"
    }
}

log-separator

# Get initial disk usage
$c_drive_pct_full_before_cleanup = get-diskusage
#values are returned in an array
# element 0 is percentage used
# element 1 is c drive size
# element 2 is free space

$basevars_hash = read-basevars
if ($($c_drive_pct_full_before_cleanup[0]) -gt $threshold_to_initiate_cleanup)
{
    write-logentrynodisplay "$script_name`: C drive free space threshold is below $($threshold_to_initiate_cleanup)% Initiating cleanup"
    for ($i=0;$i -lt $folder_to_check.count;$i++)
    {
        clean_folder $($folder_to_check[$i])
# now lets get the space after the cleanup
        
    } 
    empty_recycle_bin
    $c_drive_pct_full_after_cleanup = get-diskusage 
    $space_saved = [math]::($($c_drive_pct_full_before_cleanup[2]) - ($c_drive_pct_full_after_cleanup[2]))
    write-logentrynodisplay "$script_name`: Cleaned up $($space_saved)GB"
} 
else 
{
    write-logentrynodisplay "$script_name`: No cleanup needed"
}
